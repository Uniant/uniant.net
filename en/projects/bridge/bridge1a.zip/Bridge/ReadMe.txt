----------------------------------------------------------------------

   Bridge
     - Replace Commands for Linux to Windows

   Version: 0.1 (Public Alpha 1.0)
   Release: July 23th, 2021

   Website: https://uniant.net/projects/bridge/


   by Uniant

   Uniant Official Website      : https://uniant.net/
   Uniant Official Mail Adress: contact@uniant.net

----------------------------------------------------------------------

   Created ReadMe: July 23th, 2021

----------------------------------------------------------------------

　○ 概要

　　 Linux コマンドを Windows 用コマンドに置換し、実行します。


　○ 動作環境

　　 Windows 10 で動作を確認しています。


　○ ライセンス

　　 Uniant ソフトウェアライセンス契約が適用されます。


　○ お問い合わせ

　　 Bridge について不明な点がございましたら、サポートまでご連絡ください。

　　 Twitter: https://twitter.com/UniantSupport
　　 Website: https://support.uniant.net/

----------------------------------------------------------------------

   Copyright 2021 Uniant
